ListaDePalavras=["bruno", "leide", "karol", "marco", "carlos"]


for i in ListaDePalavras:
    print(f"\n Na palavra {i.capitalize()} temos ", end=" ")
    for Caracter in i:
        if Caracter.lower() in "aeiou":
            print (Caracter, end=" ")
