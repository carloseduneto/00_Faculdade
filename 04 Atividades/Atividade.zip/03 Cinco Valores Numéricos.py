Valores= []

for _ in range (5):
    Valores = input('Digite um número: ')
    for Chave, Valor in enumerate(Valores): 
        if Valores < Valor:
            Valores.insert(Chave,Valores )
            break
    else:
        Valores.append(Valores)
    print("Lista atual:" , Valores)