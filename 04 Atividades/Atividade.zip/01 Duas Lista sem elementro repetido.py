Lista1= [1,2,3,4,5,6,5,7]
Lista2=[2,4,5,6,7,8,9,90]
ListaNova=[]

t1= len(Lista1)
t2= len(Lista2)
tamanho = max (t1 , t2)

for i in range (tamanho):
    if i <t1 and Lista1[i] not in ListaNova:
        ListaNova.append(Lista1[i])
    if i <t2 and Lista2[i] not in ListaNova:
        ListaNova.append(Lista2[i])

print(f"Lista 1: {Lista1}")
print(f"Lista 2: {Lista2}")
print(f"Lista Intercalada: {ListaNova}")