package _01_Introducao;

import dao.ConectaDB;

public class App {

	public static void main(String[] args) {
		ConectaDB objetoConexao = new ConectaDB();
		
	}

}
