package Exercicio03;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Restaurante compra = new Restaurante();
		
		compra.valoresClientes(2, 100.99);
		System.out.println(compra.exibeResultado());
	}

}
