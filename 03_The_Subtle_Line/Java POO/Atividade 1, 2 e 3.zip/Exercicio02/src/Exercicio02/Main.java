package Exercicio02;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Veiculo Automovel;
		Automovel = new Veiculo();
		
		System.out.println(Automovel.idade(2003, 2023));
		System.out.println(Automovel.valorIPVA(20000, 1969));
		System.out.println(Automovel.valorSeguro(14000));
		
	}

}
