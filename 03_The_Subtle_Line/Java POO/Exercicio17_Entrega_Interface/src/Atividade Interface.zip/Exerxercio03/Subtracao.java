package Exerxercio03;

public class Subtracao implements OperacaoMatematica {
	private double a;
	private double b;
	
	public Subtracao() {
		
	}
	
	
	
	public double Calcule (double a, double b) {
		return a - b;
	}

}
