package Exerxercio03;

public interface OperacaoMatematica {
	public double Calcule(double a, double b);
}
