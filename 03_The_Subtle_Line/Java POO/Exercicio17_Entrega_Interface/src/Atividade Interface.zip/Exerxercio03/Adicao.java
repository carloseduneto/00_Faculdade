package Exerxercio03;

public class Adicao implements OperacaoMatematica {
	private double a;
	private double b;
	
	public Adicao() {
		
	}
	
	
	
	public double Calcule (double a, double b) {
		return a + b;
	}

}
