package Exerxercio03;

public class Multiplicacao implements OperacaoMatematica {
	private double a;
	private double b;
	
	public Multiplicacao() {
		
	}
	
	
	
	public double Calcule (double a, double b) {
		return a * b;
	}

}
