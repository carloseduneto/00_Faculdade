package Exercicio04;

public interface AnimalDeEstimacao {
	public String getNome();
	
	public void setNome(String nome);
	
	public void brincar();
}
