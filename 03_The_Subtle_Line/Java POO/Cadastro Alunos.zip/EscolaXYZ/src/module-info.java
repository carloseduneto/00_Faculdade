/**
 * 
 */
/**
 * @author Carlos
 *
 */
module EscolaXYZ {
}