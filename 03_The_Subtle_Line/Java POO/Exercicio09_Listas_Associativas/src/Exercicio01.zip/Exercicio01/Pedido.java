package Exercicio01;

public class Pedido {
    private String descricao;

    public Pedido(String descricao) {
        this.descricao = descricao;
    }

    public String getDescricao() {
        return descricao;
    }
}
