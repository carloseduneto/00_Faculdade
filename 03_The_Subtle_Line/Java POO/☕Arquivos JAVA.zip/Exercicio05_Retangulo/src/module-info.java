/**
 * 
 */
/**
 * @author Carlos
 *
 */
module Exercicio_05_Retangulo {
}