package Exercicio01;

public class Main {

	public static void main(String[] args) {
	
		Clientes donald = new Clientes("Donald", "Rua M, 99", "(34)9876-1233");
		Clientes patinhas = new Clientes("Patinhas")
		
	}

}
