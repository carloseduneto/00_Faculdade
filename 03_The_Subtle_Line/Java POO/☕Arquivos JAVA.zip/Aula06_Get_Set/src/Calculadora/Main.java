package Calculadora;

public class Main {

	public static void main(String[] args) {
		Calcula calculoSoma = new Calcula ();
		
		calculoSoma.setUmNumero(1);
		calculoSoma.setSimbolo("+");
		calculoSoma.setOutroNumero(3);
		System.out.println();

	}

}
