package Aula03;

public class Pessoa {

	String Nome = "Carlos Eduardo";
	int Idade = 22;
	double Peso;
	
	public Pessoa() {
		// TODO Auto-generated constructor stub
		Peso = 76.3;
	}
	

}
