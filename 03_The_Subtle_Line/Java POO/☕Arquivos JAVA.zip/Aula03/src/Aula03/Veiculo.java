package Aula03;

public class Veiculo {
	
	String placa;
	String modelo = "Toro";
	double Preco;

	public Veiculo() {
		// TODO Auto-generated constructor stub
		placa = "HDX2J24";
		Preco = 69000;
	}

}
