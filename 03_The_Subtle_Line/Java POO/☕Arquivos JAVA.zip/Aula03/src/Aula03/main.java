package Aula03;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Veiculo novoVeiculo = new Veiculo();
		System.out.println("Modelo: "+ novoVeiculo.modelo);
		System.out.println("Placa: "+ novoVeiculo.placa);

		
		
		
		Pessoa novaPessoa = new Pessoa();
		System.out.println("Nome: "+ novaPessoa.Nome);
		System.out.println("Idade: "+ novaPessoa.Idade);
		System.out.println("Peso: "+ novaPessoa.Peso);
	}

}
