package Empresa;

public class Main {

	public static void main(String[] args) {
		Departamento novoDepartamento = new Departamento("Psicologia", "Atendimento a Crises de Ansiedade");
		Empresa novoEmpresa = new Empresa("Jéssica", 19, 1900.99, novoDepartamento);
		
		System.out.println(novoEmpresa.setNome()+);

	}

}
