/**
 * 
 */
/**
 * @author Carlos
 *
 */
module Exercicio13_Veiculo_Estatico {
}