package _02_Exercicio_Esportes;

public class Jogadores {
	private String nome;
	private Esporte esporte;

	public Jogadores(String nome, Esporte esporte) {
		this.nome = nome;
		this.esporte = esporte;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Esporte getEsporte() {
		return esporte;
	}

	public void setEsporte(Esporte esporte) {
		this.esporte = esporte;
	}
	
	
	
	

	
}
