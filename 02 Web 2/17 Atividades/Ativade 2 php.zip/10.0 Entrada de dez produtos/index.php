<head>
<title>10.0 Entrada de dez produtos </title>
</head>
<?php 
$ListaDeFrutasEValores= array (
"Banana" => 3.25,
"Pêssego" => 5.99,
"Maçã" => 10.99,
"Laranja" => 2.99,
"Limão" => 2.49,
"Kiwi" => 6.99,
"Melancia" => 2.29,
"Mamão" => 6.89,
"Pera" => 5.79,
"Melão" => 4.79);

echo "Lista com 10 itens e seus respectivos valores";
echo "<pre>";print_r ($ListaDeFrutasEValores); echo "</pre>";
?>