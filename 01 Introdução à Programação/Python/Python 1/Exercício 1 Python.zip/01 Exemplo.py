preco=float(input("Valor do produto: "))
quantidade=float(input("Quantidade de produtos: "))
print("O valor total é R$", preco*quantidade)