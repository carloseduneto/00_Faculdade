semanas=float(input("Qual a quantidade de semanas? "))
dias=(semanas*7)
meses=(dias/30)
print("A gestação tem ", dias, " dias ", meses, " meses.")