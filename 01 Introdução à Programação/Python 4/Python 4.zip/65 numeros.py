def numero (numero1):
    if(numero1==1):
        print("Um")
    elif(numero1==2):
        print("Dois")
    elif(numero1==3):
        print("Três")
    elif(numero1==4):
        print("Quatro")
    elif(numero1==5):
        print("Cinco")
    elif(numero1==6):
        print("Seis")
    elif(numero1==7):
        print("Sete")
    elif(numero1==8):
        print("Oito")
    elif(numero1==9):
        print("Nove")
    elif(numero1==10):
        print("dez")
    else:
        print("Erro! Numero invalido!")
num=int(input("Digite um numero \n"))
numero(num)
