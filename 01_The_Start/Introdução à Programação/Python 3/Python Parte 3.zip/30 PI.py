for i  in range (50):
    if i%4==0:
        print("\nPI \n")
  		
    else:
        print(i, "\n \n")
		