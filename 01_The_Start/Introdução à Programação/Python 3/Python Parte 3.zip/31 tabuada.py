numero=int(input("Digite um número: "))
for i in range (10):
  	print("\n", numero, " x ", i," = ", numero*i)
  	