resultado=1
numero=int(input("Digite um número: "))
potencia=int(input("Digite o valor da potencialização: "))
for i in range(potencia):
    resultado=(resultado*numero)
print("O resultado é = ", resultado)