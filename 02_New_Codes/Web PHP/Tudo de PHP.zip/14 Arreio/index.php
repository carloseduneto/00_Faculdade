<body>
<?php 
	$nomeDoArreio = array	();
	
	//A função print_r() é uma função embutida no PHP e é usada para imprimir ou exibir informações aramazenadas em uma variável
	
	//printR ($NomeDoArreio);
	
	$cores= array ("vermelho", "azul", "amarelo");
	print_r($cores);
	
	$cores[1]="verde";
	print_r($cores)
?>