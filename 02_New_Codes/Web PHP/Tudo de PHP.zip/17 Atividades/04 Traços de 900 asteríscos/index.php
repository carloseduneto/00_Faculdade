<head>
<title>04 Traços de 900 asteriscos</title>
</head>

<?php 
echo str_repeat ("*",900)
?>