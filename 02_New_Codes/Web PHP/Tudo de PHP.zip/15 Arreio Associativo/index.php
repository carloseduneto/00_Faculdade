<body>
	<?php
	$estadosECapitais = array (
	"SP" => "São Paulo);
	echo sizeof($estadosECapitais);
	
	?>