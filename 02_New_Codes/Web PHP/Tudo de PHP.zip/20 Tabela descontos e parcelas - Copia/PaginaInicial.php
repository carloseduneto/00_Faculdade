<!DOCTYPE thml>
<html lang="pt-br">
<head>
	<title>Formulários HTML com PHP</title>
</head>
<body>

</br></br>
<h2 align="center">CADASTRO DE PRODUTOS</h2>
<form method="POST" action="TabelaPrecos.php" align="center">
	<input type="text" name="txtItem" placeholder="Produto"/>
	<input type="value" name="nmbValor" placeholder="Valor"/>
	</br></br>
	<input type="submit" value="Ver"/>
	<input type="reset" value="Limpar"/>
</form>

</body>