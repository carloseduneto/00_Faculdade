<!DOCTYPE html>
<html lang="pt-br">
<head>
	<title>Caluculadora 🔢</title>
<style>

input[type=value] {
height: 50px;
font: 50px;
}

</style>
</head>
<body><font size="34">
</br></br></br>
<form method="GET" action="calcular.php" align="center" >
	<font size="34"><input type="value" name="Valor1" placeholder="Valor 1"/> </font></br>
	<input type="value" name="Valor2" placeholder="Valor 2"/> </br>
	<input type="submit" name= "botao" value="Soma"/>
	<input type="submit" name="botao" value="Multiplica"/>
	<input type="submit" name="botao" value="Subtrai"/>
	<input type="reset" value="Limpar"/>
	</font>
</form>
</body>