<html>
	<head>
		<title> CATEGORIA DO ATLETA </title>
	</head>
		<body>
		<h1 align="center"> Atividade 3!<h1>
		
		<?php
		$mes=2;
		
		if ($mes==1) {
			echo "Janeiro";
			
		} else if ($mes==2) {
			echo "Fevereiro";
		
		} else if ($mes==3) {
			echo "Março";
			
		} else if ($mes==4) {
			echo "Abril";
			
		} else if ($mes==5) {
			echo "Maio";
			
		} else if ($mes==6) {
			echo "Junho";
			
		} else if ($mes==7) {
			echo "Julho";
			
		} else if ($mes==8) {
			echo "Agosto";
			
		} else if ($mes==9) {
			echo "Setembro";
			
		} else if ($mes==10) {
			echo "Outubro";
			
		} else if ($mes==11) {
			echo "Novembro";
			
		} else if ($mes==12) {
			echo "Dezembro";
			
		} else{
			echo "Não é um mês";
		}
		?>
	</body>
			
</html>