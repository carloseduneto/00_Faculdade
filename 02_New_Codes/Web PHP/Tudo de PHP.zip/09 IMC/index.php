<html>
	<head>
		<title> CATEGORIA DO ATLETA </title>
	</head>
		<body>
		<h1 align="center"> Atividade 4.2!<h1>
		
		<?php

		
		
		
		$numero = 1024;
while ($numero > 1) {
echo $numero;
$numero = $numero / 2;
"</br>";
}
		?>
	</body>
			
</html>