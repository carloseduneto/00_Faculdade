<!DOCTYPE thml>
<html lang="pt-br">
<head>
	<title>Formulários HTML com PHP</title>
</head>
<body>
<form method="POST" action="RecebeDados.php">
	<input type="text" name="txtNome" placeholder="Nome"/> </br>
	<input type="submit" value="Olá"/>
	<input type="reset" value="Limpar"/>
</form>
</body>