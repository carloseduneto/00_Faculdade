<html>
	<head>
		<title> CATEGORIA DO ATLETA </title>
	</head>
		<body>
		<h1 align="center"> Atividade 2.1!<h1>
		
		<?php
		$var1=2;
		$var2=5;
		$var3=6;
		
		if ($var1 > $var2 && $var1>$var3) {
			echo "{$var1} é a maior variável";
			
		} else if ($var2 > $var3) {
			echo "{$var2} é a maior variável";
			
		}else{
			echo "{$var3} é a maior variável";
		}
		?> 
	</body>
			
</html>