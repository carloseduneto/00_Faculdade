<?php
	//echo str_pad ("teste", 10, "-");
	//echo str_repeat("-", 100);
	//echo "</br>";
	//for ($i=0; $i<100; $i++){
	//	echo "-";
	//}
	//$frase = "você comeria salada todos os dias. ";
	//$saudavel = "salada";
	//$saboroso = "bacon";
	//echo str_replace ($saudavel, $saboroso, $frase);
	
	
	//echo strlen($saboroso);
	//echo strrev($saboroso);
	
	//echo substr('Leide', 0, 3);
	$data= "2022/08/16";
	echo substr($data, 8, 10). substr($data, 5, 2). substr($data, 0,4);//ponto concatena //quantidade de caracteres
	?>

