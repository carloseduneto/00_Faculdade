'''
Matrizes são um conjunto de listas (vetores)
'''

matrizGruposABCD=[
                                  0  ["Catar", "Equador", "Senagal", "Holanda"],
                                   1 ["Inglaterra", "Irã", "Estados Unidos", "Países Gales"],
                                   2 ["Argentina", "Arábia Saudita", "México", "Polônia"],
                                   3 ["França", "Austrália", "Dinamarca", "Tunísia"]
                                    ]

time=matrizGruposABCD[0][0]
print(time)

# mudar time
# matrizGruposABCD[0][3]="Minas Gerais"
# print(matrizGruposABCD)

# for linha in matrizGruposABCD:
#     print(linha)

# for linha in matrizGruposABCD:
#     for coluna in linha:
#         print(coluna)

# for linha in range(len( matrizGruposABCD)):
#     for coluna in range(len(matrizGruposABCD[linha])):
#         matrizGruposABCD[linha][coluna]="Brasil"
# print(matrizGruposABCD)

